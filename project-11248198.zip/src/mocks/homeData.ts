export const servicesData = [
  {
    id: 1,
    title: 'Cybersecurity Risk Assessment',
    description:
      'Identify vulnerabilities that could expose your business to threats. We evaluate your systems, networks, and practices to uncover risks before attackers do.',
    icon: 'ri-shield-keyhole-line',
  },
  {
    id: 2,
    title: 'IT Infrastructure Consulting',
    description:
      'Guidance on network architecture, system design, and technology planning. We help you build scalable, reliable infrastructure that supports your growth.',
    icon: 'ri-server-line',
  },
  {
    id: 3,
    title: 'Backup & Disaster Recovery',
    description:
      'Protect critical business data and ensure recovery capability. We design backup strategies and disaster recovery plans tailored to your operations.',
    icon: 'ri-database-2-line',
  },
  {
    id: 4,
    title: 'Microsoft 365 Security',
    description:
      'Enhance cloud and email security with MFA, conditional access, and best practices. Secure your Microsoft environment against modern threats.',
    icon: 'ri-cloud-line',
  },
  {
    id: 5,
    title: 'IT Vendor Advisory',
    description:
      'Oversight and advice to ensure outsourced IT providers deliver secure, reliable services. We act as your independent technology advocate.',
    icon: 'ri-service-line',
  },
  {
    id: 6,
    title: 'Compliance & Governance',
    description:
      'Navigate regulatory requirements with confidence. We help establish IT policies, audit readiness, and governance frameworks for your industry.',
    icon: 'ri-file-shield-line',
  },
];

export const industriesData = [
  {
    id: 1,
    name: 'Medical & Healthcare Clinics',
    description:
      'Protect patient data, improve system reliability, and ensure compliance with healthcare privacy regulations.',
    icon: 'ri-hospital-line',
    image:
      'https://readdy.ai/api/search-image?query=Bright%20modern%20medical%20clinic%20interior%20with%20friendly%20healthcare%20professionals%20interacting%20with%20patients%20warm%20natural%20lighting%20clean%20welcoming%20environment%20lifestyle%20photography%20colorful%20professional%20atmosphere%20high%20quality&width=400&height=280&seq=ind1v2&orientation=landscape',
  },
  {
    id: 2,
    name: 'Professional Service Firms',
    description:
      'Secure client information for accounting, legal, and consulting firms with tailored cybersecurity strategies.',
    icon: 'ri-briefcase-line',
    image:
      'https://readdy.ai/api/search-image?query=Diverse%20group%20of%20professional%20business%20people%20having%20a%20collaborative%20meeting%20in%20a%20bright%20modern%20office%20with%20large%20windows%20natural%20sunlight%20colorful%20professional%20lifestyle%20photography%20warm%20tones%20high%20quality&width=400&height=280&seq=ind2v2&orientation=landscape',
  },
  {
    id: 3,
    name: 'Engineering & Construction',
    description:
      'Safeguard project data, technical drawings, and remote access systems for distributed teams.',
    icon: 'ri-building-line',
    image:
      'https://readdy.ai/api/search-image?query=Construction%20team%20reviewing%20building%20plans%20at%20an%20active%20construction%20site%20wearing%20safety%20gear%20bright%20daylight%20outdoor%20scene%20colorful%20professional%20lifestyle%20photography%20industrial%20atmosphere%20high%20quality&width=400&height=280&seq=ind3v2&orientation=landscape',
  },
  {
    id: 4,
    name: 'Small & Growing Businesses',
    description:
      'Establish reliable, secure IT environments that scale with your business as you grow.',
    icon: 'ri-store-2-line',
    image:
      'https://readdy.ai/api/search-image?query=Happy%20small%20business%20owner%20greeting%20customers%20in%20a%20bright%20modern%20local%20shop%20or%20cafe%20with%20warm%20colorful%20interior%20design%20natural%20lighting%20welcoming%20atmosphere%20lifestyle%20photography%20high%20quality&width=400&height=280&seq=ind4v2&orientation=landscape',
  },
];

export const whyUsData = [
  {
    id: 1,
    title: '20+ Years Experience',
    description:
      'Deep expertise in IT infrastructure and enterprise technology operations across regional and global environments.',
    icon: 'ri-trophy-line',
  },
  {
    id: 2,
    title: 'Independent Advice',
    description:
      'Recommendations focused on your business goals, not vendor incentives. Unbiased guidance you can trust.',
    icon: 'ri-scales-3-line',
  },
  {
    id: 3,
    title: 'Practical Solutions',
    description:
      'Solutions that are secure, reliable, and cost-effective. No unnecessary complexity — just what works.',
    icon: 'ri-tools-line',
  },
  {
    id: 4,
    title: 'Personalized Service',
    description:
      'Work closely with business owners to understand operational goals and deliver tailored IT strategies.',
    icon: 'ri-user-heart-line',
  },
  {
    id: 5,
    title: 'Edmonton Based',
    description:
      'Local presence means responsive support and a genuine understanding of the Alberta business landscape.',
    icon: 'ri-map-pin-line',
  },
  {
    id: 6,
    title: 'Proven Results',
    description:
      'Track record of strengthening IT environments for organizations in healthcare, professional services, and more.',
    icon: 'ri-bar-chart-box-line',
  },
];