import { useScrollReveal } from '@/hooks/useScrollReveal';
import { whyUsData } from '@/mocks/homeData';

export default function WhyUsSection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.08 });

  return (
    <section
      id="why-us"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-f-dark-2 overflow-hidden"
    >
      {/* Background accent */}
      <div className="absolute top-1/2 right-0 w-[300px] h-[300px] rounded-full bg-f-cyan/3 blur-[100px] -translate-y-1/2" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        {/* Section Header */}
        <div
          className={`max-w-3xl mb-14 md:mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center gap-2 border border-f-cyan/30 rounded-full px-4 py-1.5 mb-4">
            <span className="text-f-cyan text-xs font-medium tracking-wider uppercase">
              Why Foonex Solutions
            </span>
          </div>
          <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[2.75rem] text-white leading-tight">
            Trusted Expertise,{' '}
            <span className="text-f-cyan">Personalized</span> Approach
          </h2>
        </div>

        {/* Why Us Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {whyUsData.map((item, index) => (
            <div
              key={item.id}
              className={`group bg-f-slate/30 border border-f-border/30 hover:border-f-cyan/25 rounded-xl p-6 transition-all duration-500 hover:bg-f-slate/50 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${150 + index * 100}ms` }}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className="w-11 h-11 rounded-xl bg-f-cyan/10 border border-f-cyan/20 flex items-center justify-center text-f-cyan flex-shrink-0 group-hover:bg-f-cyan/15 transition-all duration-300">
                  <span className="w-5 h-5 flex items-center justify-center">
                    <i className={`${item.icon} text-lg`} />
                  </span>
                </div>

                {/* Content */}
                <div>
                  <h3 className="text-white font-semibold text-base mb-1.5 group-hover:text-f-cyan transition-colors duration-300">
                    {item.title}
                  </h3>
                  <p className="text-f-text-dim text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}