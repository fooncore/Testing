import { useScrollReveal } from '@/hooks/useScrollReveal';
import { servicesData } from '@/mocks/homeData';

export default function ServicesSection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.08 });

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-f-dark-2 overflow-hidden"
    >
      {/* Background accent */}
      <div className="absolute top-0 right-1/4 w-[400px] h-[400px] rounded-full bg-f-cyan/3 blur-[120px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        {/* Section Header */}
        <div
          className={`max-w-3xl mb-14 md:mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <p className="text-f-cyan text-xs font-semibold uppercase tracking-wider mb-3">
            What We Do
          </p>
          <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[2.75rem] text-white leading-tight mb-4">
            Core Services to Protect &amp; Strengthen Your Business
          </h2>
          <p className="text-f-text-muted text-base md:text-lg leading-relaxed">
            From risk assessment to ongoing advisory, we provide the IT expertise your
            business needs to stay secure, compliant, and resilient.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {servicesData.map((service, index) => (
            <div
              key={service.id}
              className={`group bg-f-slate/40 border border-f-border/30 hover:border-f-cyan/30 rounded-xl p-6 md:p-7 transition-all duration-500 hover:bg-f-slate/60 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${150 + index * 100}ms` }}
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-f-cyan/10 border border-f-cyan/20 flex items-center justify-center text-f-cyan mb-5 group-hover:bg-f-cyan/15 transition-all duration-300">
                <span className="w-6 h-6 flex items-center justify-center">
                  <i className={`${service.icon} text-xl`} />
                </span>
              </div>

              {/* Title */}
              <h3 className="text-white font-semibold text-lg mb-3 group-hover:text-f-cyan transition-colors duration-300">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-f-text-dim text-sm leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}