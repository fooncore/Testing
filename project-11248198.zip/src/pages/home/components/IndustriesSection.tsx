import { useScrollReveal } from '@/hooks/useScrollReveal';
import { industriesData } from '@/mocks/homeData';

export default function IndustriesSection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.08 });

  return (
    <section
      id="industries"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-f-dark overflow-hidden"
    >
      {/* Background accent */}
      <div className="absolute bottom-0 left-1/3 w-[350px] h-[350px] rounded-full bg-f-cyan/3 blur-[100px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        {/* Section Header */}
        <div
          className={`max-w-3xl mb-14 md:mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <p className="text-f-cyan text-xs font-semibold uppercase tracking-wider mb-3">
            Who We Help
          </p>
          <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[2.75rem] text-white leading-tight mb-4">
            Industries We Serve
          </h2>
          <p className="text-f-text-muted text-base md:text-lg leading-relaxed">
            We understand the unique technology challenges of different industries and tailor
            our approach to meet specific compliance, security, and operational requirements.
          </p>
        </div>

        {/* Industries Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {industriesData.map((industry, index) => (
            <div
              key={industry.id}
              className={`group bg-f-slate/30 border border-f-border/30 hover:border-f-cyan/30 rounded-xl overflow-hidden transition-all duration-500 hover:bg-f-slate/50 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${150 + index * 100}ms` }}
            >
              {/* Image */}
              <div className="aspect-[4/3] w-full bg-f-slate relative overflow-hidden">
                <img
                  src={industry.image}
                  alt={industry.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-f-dark/70 via-f-dark/20 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="w-9 h-9 rounded-lg bg-f-dark/70 backdrop-blur-sm border border-f-border/30 flex items-center justify-center text-f-cyan">
                    <span className="w-5 h-5 flex items-center justify-center">
                      <i className={`${industry.icon} text-base`} />
                    </span>
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="text-white font-semibold text-base mb-2 group-hover:text-f-cyan transition-colors duration-300">
                  {industry.name}
                </h3>
                <p className="text-f-text-dim text-sm leading-relaxed">
                  {industry.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}