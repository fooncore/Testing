import { useScrollReveal } from '@/hooks/useScrollReveal';

export default function HeroSection() {
  const { ref: heroRef, isVisible } = useScrollReveal<HTMLDivElement>({
    threshold: 0.05,
    triggerOnce: true,
  });

  const handleCtaClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const target = document.querySelector('#contact');
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-[100vh] flex items-center overflow-hidden bg-f-dark"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.04]">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#00D4D4" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Gradient Orbs */}
      <div className="absolute top-20 right-0 w-[500px] h-[500px] rounded-full bg-f-cyan/5 blur-[120px]" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-f-cyan/3 blur-[100px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16 pt-24 md:pt-28 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">
          {/* Left Content */}
          <div className="lg:col-span-7 xl:col-span-6">
            <div
              className={`transition-all duration-1000 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              {/* Label */}
              <div className="inline-flex items-center gap-2 border border-f-border/60 rounded-full px-4 py-1.5 mb-6">
                <span className="w-1.5 h-1.5 rounded-full bg-f-cyan animate-pulse" />
                <span className="text-f-cyan text-xs font-medium tracking-wider uppercase">
                  Edmonton, Canada
                </span>
              </div>

              {/* Headline */}
              <h1 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] xl:text-[3.5rem] text-white leading-[1.15] tracking-tight mb-6">
                Cybersecurity &amp;{' '}
                <span className="text-f-cyan">IT Infrastructure</span>{' '}
                Consulting for SMEs
              </h1>

              {/* Slogan */}
              <p className="text-f-cyan font-display text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold tracking-tight mb-6">
                Your One-Stop IT Management Partner
              </p>

              {/* Subheadline */}
              <p className="text-f-text-muted text-base md:text-lg leading-relaxed max-w-xl mb-8">
                Helping clinics, professional firms, and growing organizations secure
                systems, protect sensitive data, and improve technology reliability.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="#contact"
                  onClick={handleCtaClick}
                  className="inline-flex items-center justify-center gap-2 bg-f-cyan text-f-dark px-7 py-3.5 rounded-full text-sm font-semibold hover:bg-f-cyan-dark transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,212,212,0.25)] whitespace-nowrap cursor-pointer"
                >
                  Book a Free 30-Minute Consultation
                  <span className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-arrow-right-up-line text-sm" />
                  </span>
                </a>
                <a
                  href="#services"
                  onClick={(e) => {
                    e.preventDefault();
                    document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className="inline-flex items-center justify-center gap-2 border border-f-border/60 text-f-text-muted px-7 py-3.5 rounded-full text-sm font-medium hover:border-f-cyan/40 hover:text-white transition-all duration-300 whitespace-nowrap cursor-pointer"
                >
                  Explore Our Services
                  <span className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-arrow-down-line text-sm" />
                  </span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="lg:col-span-5 xl:col-span-6">
            <div
              className={`relative transition-all duration-1000 delay-300 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
              }`}
            >
              {/* Main Image Card */}
              <div className="relative rounded-2xl overflow-hidden border border-f-border/30">
                <div className="aspect-[4/3] w-full bg-f-slate relative">
                  <img
                    src="https://readdy.ai/api/search-image?query=Abstract%20cybersecurity%20digital%20shield%20with%20network%20nodes%20and%20data%20streams%20dark%20blue%20background%20cyan%20glowing%20accents%20modern%20tech%20illustration%20minimal%20clean%20professional%20corporate%20aesthetic%20high%20quality%203D%20render&width=600&height=450&seq=hero1&orientation=landscape"
                    alt="Cybersecurity and IT Infrastructure"
                    className="w-full h-full object-cover"
                    loading="eager"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-f-dark/60 via-transparent to-transparent" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}