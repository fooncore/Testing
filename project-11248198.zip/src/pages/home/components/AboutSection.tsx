import { useScrollReveal } from '@/hooks/useScrollReveal';

export default function AboutSection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-f-dark overflow-hidden"
    >
      {/* Subtle background accent */}
      <div className="absolute top-1/2 left-0 w-[300px] h-[300px] rounded-full bg-f-cyan/3 blur-[100px] -translate-y-1/2" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
          {/* Left: Image Area */}
          <div className="lg:col-span-5">
            <div
              className={`transition-all duration-1000 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              {/* Label */}
              <div className="inline-flex items-center gap-2 border border-f-cyan/30 rounded-full px-4 py-1.5 mb-6">
                <span className="text-f-cyan text-xs font-medium tracking-wider uppercase">
                  About Us
                </span>
              </div>

              {/* Founder Image */}
              <div className="relative rounded-2xl overflow-hidden border border-f-border/30">
                <div className="aspect-[3/4] w-full bg-f-slate">
                  <img
                    src="https://readdy.ai/api/search-image?query=Professional%20male%20business%20executive%20portrait%20in%20modern%20office%20setting%20dark%20ambient%20lighting%20confident%20expression%20formal%20attire%20high%20quality%20headshot%20photography%20minimal%20clean%20background%20subtle%20cyan%20lighting%20accent&width=450&height=600&seq=founder1&orientation=portrait"
                    alt="Tony Siu - Founder of Foonex Solutions"
                    className="w-full h-full object-cover object-top"
                    loading="lazy"
                  />
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-f-dark/90 via-f-dark/40 to-transparent p-6">
                  <p className="text-white font-display font-bold text-xl">Tony Siu</p>
                  <p className="text-f-cyan text-sm mt-0.5">Founder &amp; Lead Consultant</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Text Content */}
          <div className="lg:col-span-7">
            <div
              className={`transition-all duration-1000 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[2.75rem] text-white leading-tight mb-6">
                Independent IT Consulting Built on{' '}
                <span className="text-f-cyan">20 Years</span> of Enterprise Experience
              </h2>

              <p className="text-f-text-muted text-base md:text-lg leading-relaxed mb-6">
                Based in Edmonton, we provide independent IT consulting to help small and
                medium-sized businesses improve security, reliability, and performance.
                With over 20 years of experience in IT infrastructure, network systems, and
                enterprise technology operations, we deliver practical expertise in
                cybersecurity, backup and disaster recovery, cloud security, and network
                consulting.
              </p>

              <p className="text-f-text-dim text-base leading-relaxed mb-8">
                We work closely with clients to identify technology risks, strengthen system
                resilience, and ensure IT solutions support long-term business goals. Our
                approach is rooted in understanding your unique environment before
                recommending solutions.
              </p>

              {/* Founder Bio Card */}
              <div className="bg-f-slate/50 border border-f-border/30 rounded-xl p-5 md:p-6">
                <div className="flex items-start gap-4">
                  <span className="w-12 h-12 rounded-full bg-f-cyan/10 flex items-center justify-center text-f-cyan flex-shrink-0">
                    <span className="w-6 h-6 flex items-center justify-center">
                      <i className="ri-user-star-line text-xl" />
                    </span>
                  </span>
                  <div>
                    <h4 className="text-white font-semibold text-base mb-1">Tony Siu</h4>
                    <p className="text-f-text-dim text-sm leading-relaxed">
                      An IT infrastructure professional with 20+ years of experience in
                      enterprise technology. He held senior IT roles supporting regional and
                      global operations for companies such as Godiva and Lee Kum Kee. He now
                      focuses on helping Edmonton businesses strengthen their IT environment
                      with practical, secure, and cost-effective solutions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}