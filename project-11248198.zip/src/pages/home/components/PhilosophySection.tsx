import { useScrollReveal } from '@/hooks/useScrollReveal';

export default function PhilosophySection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.08 });

  const approachSteps = [
    {
      step: '01',
      title: 'Understand',
      desc: 'Your business and technology environment',
    },
    {
      step: '02',
      title: 'Identify',
      desc: 'IT and cybersecurity risks',
    },
    {
      step: '03',
      title: 'Recommend',
      desc: 'Practical, cost-effective solutions',
    },
    {
      step: '04',
      title: 'Support',
      desc: 'Implementation with internal or external teams',
    },
  ];

  return (
    <section
      id="philosophy"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-f-dark-2 overflow-hidden"
    >
      {/* Background accents */}
      <div className="absolute top-0 left-1/4 w-[400px] h-[400px] rounded-full bg-f-cyan/3 blur-[120px]" />
      <div className="absolute bottom-0 right-1/4 w-[300px] h-[300px] rounded-full bg-f-cyan/2 blur-[100px]" />

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        {/* Section Header */}
        <div
          className={`text-center max-w-3xl mx-auto mb-14 md:mb-20 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <div className="inline-flex items-center gap-2 border border-f-cyan/30 rounded-full px-4 py-1.5 mb-5">
            <span className="text-f-cyan text-xs font-medium tracking-wider uppercase">
              What Drives Us
            </span>
          </div>
          <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[3rem] text-white leading-tight">
            Mission, Vision &amp;{' '}
            <span className="text-f-cyan">Our Approach</span>
          </h2>
        </div>

        {/* Mission & Vision Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8 mb-16 md:mb-20">
          {/* Mission */}
          <div
            className={`group bg-f-slate/40 border border-f-border/30 hover:border-f-cyan/25 rounded-2xl p-8 md:p-10 transition-all duration-700 hover:bg-f-slate/60 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '150ms' }}
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="w-12 h-12 rounded-xl bg-f-cyan/10 border border-f-cyan/20 flex items-center justify-center text-f-cyan">
                <span className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-focus-3-line text-xl" />
                </span>
              </span>
              <h3 className="text-white font-display font-bold text-xl md:text-2xl">
                Our Mission
              </h3>
            </div>
            <p className="text-f-text-muted text-base md:text-lg leading-relaxed">
              Deliver reliable, secure, and cost-effective IT solutions that help small
              and medium-sized businesses grow while minimizing technology risks.
            </p>
          </div>

          {/* Vision */}
          <div
            className={`group bg-f-slate/40 border border-f-border/30 hover:border-f-cyan/25 rounded-2xl p-8 md:p-10 transition-all duration-700 hover:bg-f-slate/60 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '300ms' }}
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="w-12 h-12 rounded-xl bg-f-cyan/10 border border-f-cyan/20 flex items-center justify-center text-f-cyan">
                <span className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-eye-line text-xl" />
                </span>
              </span>
              <h3 className="text-white font-display font-bold text-xl md:text-2xl">
                Our Vision
              </h3>
            </div>
            <p className="text-f-text-muted text-base md:text-lg leading-relaxed">
              Become a trusted technology advisor for organizations without dedicated IT
              leadership, providing practical expertise to build secure, resilient, and
              future-ready technology environments.
            </p>
          </div>
        </div>

        {/* Our Approach */}
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{ transitionDelay: '450ms' }}
        >
          <div className="text-center mb-10 md:mb-12">
            <h3 className="font-display font-bold text-2xl md:text-3xl text-white mb-3">
              How We <span className="text-f-cyan">Work</span>
            </h3>
            <p className="text-f-text-muted text-base md:text-lg max-w-2xl mx-auto">
              A structured, four-step process designed to understand your needs and deliver
              practical results.
            </p>
          </div>

          {/* Approach Steps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
            {approachSteps.map((item, index) => (
              <div
                key={item.step}
                className={`relative bg-f-slate/30 border border-f-border/30 hover:border-f-cyan/25 rounded-xl p-6 md:p-7 transition-all duration-500 hover:bg-f-slate/50 group ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${500 + index * 100}ms` }}
              >
                {/* Connector line for desktop */}
                {index < approachSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 -right-3 w-6 h-[2px] bg-f-border/40 group-hover:bg-f-cyan/30 transition-colors duration-300" />
                )}

                {/* Step Number */}
                <span className="font-display font-bold text-4xl md:text-5xl text-f-cyan/15 group-hover:text-f-cyan/25 transition-colors duration-300 block mb-4">
                  {item.step}
                </span>

                {/* Title */}
                <h4 className="text-white font-semibold text-lg md:text-xl mb-2 group-hover:text-f-cyan transition-colors duration-300">
                  {item.title}
                </h4>

                {/* Description */}
                <p className="text-f-text-muted text-sm md:text-base leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}