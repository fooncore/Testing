import { useState } from 'react';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export default function CTASection() {
  const { ref: sectionRef, isVisible } = useScrollReveal<HTMLDivElement>({ threshold: 0.1 });
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    if (name === 'message' && value.length > 500) return;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setFormStatus('submitting');

    try {
      const data = new URLSearchParams();
      data.append('name', formData.name);
      data.append('email', formData.email);
      data.append('company', formData.company);
      data.append('message', formData.message);

      const response = await fetch('https://readdy.ai/api/form/d7pppt7b5ro7pimqgalg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });

      if (response.ok) {
        setFormStatus('success');
        setFormData({ name: '', email: '', company: '', message: '' });
      } else {
        setFormStatus('error');
      }
    } catch {
      setFormStatus('error');
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-20 md:py-28 overflow-hidden"
    >
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src="https://readdy.ai/api/search-image?query=Modern%20server%20room%20with%20blue%20LED%20lighting%20data%20center%20racks%20dark%20atmosphere%20professional%20technology%20infrastructure%20cybersecurity%20environment%20high%20quality%20photography%20minimal%20clean%20composition&width=1400&height=600&seq=cta1&orientation=landscape"
          alt="Technology Infrastructure"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-f-dark/85" />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Content */}
          <div
            className={`transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <p className="text-f-cyan text-xs font-semibold uppercase tracking-wider mb-4">
              Get Started
            </p>
            <h2 className="font-display font-bold text-3xl md:text-4xl lg:text-[2.75rem] text-white leading-tight mb-6">
              Book Your Free{' '}
              <span className="text-f-cyan">30-Minute</span> Consultation
            </h2>
            <p className="text-f-text-muted text-base md:text-lg leading-relaxed mb-8 max-w-lg">
              Discuss your IT and cybersecurity needs with an experienced consultant and
              receive practical recommendations to improve your technology environment.
              No obligation, no pressure — just expert advice.
            </p>

            {/* Benefits */}
            <div className="space-y-3 mb-8">
              {[
                'No-cost initial assessment',
                'Personalized recommendations',
                'Actionable next steps',
                'Flexible scheduling',
              ].map((benefit, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-5 h-5 rounded-full bg-f-cyan/10 flex items-center justify-center text-f-cyan">
                    <span className="w-3 h-3 flex items-center justify-center">
                      <i className="ri-check-line text-xs" />
                    </span>
                  </span>
                  <span className="text-f-text-muted text-sm">{benefit}</span>
                </div>
              ))}
            </div>

            {/* Contact Info */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex items-center gap-3 text-f-text-dim text-sm">
                <span className="w-9 h-9 rounded-lg bg-f-cyan/10 flex items-center justify-center text-f-cyan">
                  <span className="w-4 h-4 flex items-center justify-center">
                    <i className="ri-map-pin-line text-sm" />
                  </span>
                </span>
                Edmonton, AB, Canada
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div
            className={`transition-all duration-1000 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            <div className="bg-f-dark/80 backdrop-blur-xl border border-f-border/40 rounded-2xl p-6 md:p-8">
              {formStatus === 'success' ? (
                <div className="text-center py-8">
                  <span className="w-16 h-16 rounded-full bg-f-cyan/10 flex items-center justify-center text-f-cyan mx-auto mb-4">
                    <span className="w-8 h-8 flex items-center justify-center">
                      <i className="ri-check-double-line text-2xl" />
                    </span>
                  </span>
                  <h3 className="text-white font-semibold text-xl mb-2">
                    Thank You!
                  </h3>
                  <p className="text-f-text-muted text-sm">
                    We have received your request and will reach out within 24 hours to
                    schedule your consultation.
                  </p>
                  <button
                    onClick={() => setFormStatus('idle')}
                    className="mt-6 inline-flex items-center gap-2 border border-f-border/60 text-f-text-muted px-5 py-2.5 rounded-full text-sm font-medium hover:border-f-cyan/40 hover:text-white transition-all duration-300 whitespace-nowrap cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-f-text-dim text-xs font-medium mb-1.5">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full bg-f-slate/50 border border-f-border/40 rounded-lg px-4 py-3 text-white text-sm placeholder-f-text-dim/60 focus:outline-none focus:border-f-cyan/40 focus:ring-1 focus:ring-f-cyan/20 transition-all"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-f-text-dim text-xs font-medium mb-1.5">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full bg-f-slate/50 border border-f-border/40 rounded-lg px-4 py-3 text-white text-sm placeholder-f-text-dim/60 focus:outline-none focus:border-f-cyan/40 focus:ring-1 focus:ring-f-cyan/20 transition-all"
                        placeholder="john@company.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-f-text-dim text-xs font-medium mb-1.5">
                      Company Name
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full bg-f-slate/50 border border-f-border/40 rounded-lg px-4 py-3 text-white text-sm placeholder-f-text-dim/60 focus:outline-none focus:border-f-cyan/40 focus:ring-1 focus:ring-f-cyan/20 transition-all"
                      placeholder="Your company"
                    />
                  </div>

                  <div>
                    <label className="block text-f-text-dim text-xs font-medium mb-1.5">
                      How Can We Help? *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={4}
                      maxLength={500}
                      className="w-full bg-f-slate/50 border border-f-border/40 rounded-lg px-4 py-3 text-white text-sm placeholder-f-text-dim/60 focus:outline-none focus:border-f-cyan/40 focus:ring-1 focus:ring-f-cyan/20 transition-all resize-none"
                      placeholder="Tell us about your IT challenges or goals..."
                    />
                    <p className="text-f-text-dim/70 text-xs mt-1 text-right">
                      {formData.message.length}/500
                    </p>
                  </div>

                  {formStatus === 'error' && (
                    <p className="text-red-400 text-sm">
                      Something went wrong. Please try again.
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full inline-flex items-center justify-center gap-2 bg-f-cyan text-f-dark px-6 py-3.5 rounded-full text-sm font-semibold hover:bg-f-cyan-dark transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,212,212,0.25)] disabled:opacity-60 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
                  >
                    {formStatus === 'submitting' ? (
                      <>
                        <span className="w-4 h-4 border-2 border-f-dark/30 border-t-f-dark rounded-full animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        Schedule Your Consultation
                        <span className="w-4 h-4 flex items-center justify-center">
                          <i className="ri-arrow-right-up-line text-sm" />
                        </span>
                      </>
                    )}
                  </button>

                  <p className="text-f-text-dim/70 text-xs text-center">
                    We respect your privacy. Your information will never be shared.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}