import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import AboutSection from './components/AboutSection';
import PhilosophySection from './components/PhilosophySection';
import IndustriesSection from './components/IndustriesSection';
import WhyUsSection from './components/WhyUsSection';
import CTASection from './components/CTASection';

export default function Home() {
  return (
    <div className="min-h-screen bg-f-dark">
      <Navbar />
      <main>
        <HeroSection />
        <ServicesSection />
        <AboutSection />
        <PhilosophySection />
        <IndustriesSection />
        <WhyUsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
