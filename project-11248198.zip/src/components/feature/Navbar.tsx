import { useState, useEffect } from 'react';

const navLinks = [
  { label: 'Services', href: '#services' },
  { label: 'About', href: '#about' },
  { label: 'Mission', href: '#philosophy' },
  { label: 'Industries', href: '#industries' },
  { label: 'Why Us', href: '#why-us' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-f-dark/90 backdrop-blur-xl border-b border-f-border/50'
          : 'bg-transparent'
      }`}
    >
      <div className="w-full px-4 sm:px-6 lg:px-10 xl:px-16">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center group">
            <img 
              src="https://storage.readdy-site.link/project_files/a07f9136-071b-4b00-af3a-2032f334ca2f/aa0bf8b6-0366-4049-805e-905230cd9c78_compressed_Fooncore-4.webp" 
              alt="FoonCore Solutions" 
              className="h-8 md:h-10 w-auto"
            />
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="relative text-sm font-medium text-f-text-muted hover:text-white transition-colors duration-300 py-1 uppercase tracking-wide"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-f-cyan transition-all duration-300 hover:w-full group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* CTA Button Desktop */}
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="hidden md:inline-flex items-center gap-2 bg-f-cyan text-f-dark px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-f-cyan-dark transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,212,212,0.25)] whitespace-nowrap cursor-pointer"
          >
            Book a Consultation
            <span className="w-4 h-4 flex items-center justify-center">
              <i className="ri-arrow-right-up-line text-xs" />
            </span>
          </a>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center text-white cursor-pointer"
            aria-label="Toggle menu"
          >
            <span className="w-5 h-5 flex items-center justify-center">
              <i className={`ri-${mobileOpen ? 'close' : 'menu'}-line text-xl`} />
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-500 ${
          mobileOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-4 pb-6 pt-2 bg-f-dark/95 backdrop-blur-xl border-t border-f-border/30">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="block py-3 text-sm font-medium text-f-text-muted hover:text-f-cyan transition-colors uppercase tracking-wide border-b border-f-border/20"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="mt-4 inline-flex items-center gap-2 bg-f-cyan text-f-dark px-5 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap cursor-pointer"
          >
            Book a Consultation
            <span className="w-4 h-4 flex items-center justify-center">
              <i className="ri-arrow-right-up-line text-xs" />
            </span>
          </a>
        </div>
      </div>
    </nav>
  );
}