const footerLinks = {
  Services: [
    'Cybersecurity Risk Assessment',
    'IT Infrastructure Consulting',
    'Backup & Disaster Recovery',
    'Microsoft 365 Security',
    'IT Vendor Advisory',
  ],
  Industries: ['Healthcare Clinics', 'Professional Services', 'Engineering & Construction', 'Small Businesses'],
  About: ['Our Story', 'Our Approach', 'Mission & Vision'],
  Contact: ['Book a Consultation', 'Email Us', 'Edmonton, AB, Canada'],
};

export default function Footer() {
  return (
    <footer className="bg-f-footer border-t border-f-border/30">
      <div className="w-full px-4 sm:px-6 lg:px-10 xl:px-16 py-14 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-10 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div className="mb-5">
              <img 
                src="https://storage.readdy-site.link/project_files/a07f9136-071b-4b00-af3a-2032f334ca2f/aa0bf8b6-0366-4049-805e-905230cd9c78_compressed_Fooncore-4.webp" 
                alt="FoonCore Solutions" 
                className="h-10 w-auto"
              />
            </div>
            <p className="text-f-text-dim text-sm leading-relaxed max-w-xs mb-6">
              Trusted IT Consulting. Built for Edmonton. Independent cybersecurity and infrastructure advisory for growing organizations.
            </p>
            <p className="text-f-text-dim text-xs">
              Edmonton, Alberta, Canada
            </p>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="text-f-cyan text-xs font-semibold uppercase tracking-wider mb-4">
                {title}
              </h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <span className="text-f-text-dim text-sm hover:text-white transition-colors duration-300 cursor-default">
                      {link}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="mt-14 pt-8 border-t border-f-border/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-f-text-dim text-xs">
            &copy; {new Date().getFullYear()} Foonex Solutions. All rights reserved.
          </p>
          <div className="flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg border border-f-border/40 flex items-center justify-center text-f-text-dim hover:text-f-cyan hover:border-f-cyan/40 transition-all duration-300 cursor-pointer">
              <i className="ri-linkedin-fill text-sm" />
            </span>
            <span className="w-9 h-9 rounded-lg border border-f-border/40 flex items-center justify-center text-f-text-dim hover:text-f-cyan hover:border-f-cyan/40 transition-all duration-300 cursor-pointer">
              <i className="ri-mail-line text-sm" />
            </span>
          </div>
          <span className="text-f-text-dim text-xs hover:text-f-text-muted transition-colors cursor-default">
            Privacy Policy
          </span>
        </div>
      </div>
    </footer>
  );
}